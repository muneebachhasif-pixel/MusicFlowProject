/* =====================================================
   APP.JS - single file for all pages (home/search/player/library/contact)
   Place this as app.js and include in every HTML page.
===================================================== */

/* -------------------------
   SONG DATABASE (7)
------------------------- */
const songs = {
  1: { title: "Blue", artist: "Billie Eilish", img: "images/song1.jpg", file: "songs/song1.mp3" },
  2: { title: "My Love Mine All Mine", artist: "Mitski", img: "images/song2.jpg", file: "songs/song2.mp3" },
  3: { title: "Night Changes", artist: "Zayn Malik", img: "images/song3.jpg", file: "songs/song3.mp3" },
  4: { title: "Pocketful Of Sunshine", artist: "Natasha", img: "images/song4.jpg", file: "songs/song4.mp3" },
  5: { title: "Something About You", artist: "Dent May", img: "images/song5.jpg", file: "songs/song5.mp3" },
  6: { title: "Girl", artist: "Adam Doleac", img: "images/song6.jpg", file: "songs/song6.mp3" },
  7: { title: "Paper Rings", artist: "Taylor Swift", img: "images/song7.jpg", file: "songs/song7.mp3" }
};

/* -------------------------
   UTILS
------------------------- */
function el(id) { return document.getElementById(id); }
function exists(id) { return !!document.getElementById(id); }
function openSong(id) { window.location.href = "song.html?id=" + id; }

/* -------------------------
   RENDER HOME LIST (index.html)
------------------------- */
function renderHomeList() {
  const homeList = el("homeList");
  if (!homeList) return;
  homeList.innerHTML = "";
  Object.keys(songs).forEach(id => {
    const s = songs[id];
    homeList.innerHTML += `
      <div class="song-card" onclick="openSong(${id})">
        <img src="${s.img}" alt="${s.title}">
        <div class="song-info">
          <b>${s.title}</b>
          <small>${s.artist}</small>
        </div>
      </div>
    `;
  });
}

/* -------------------------
   LOAD SONG PAGE (song.html)
------------------------- */
function loadSongPage() {
  const params = new URLSearchParams(window.location.search);
  const id = params.get("id");
  if (!id || !songs[id]) return;

  const s = songs[id];

  if (exists("songImage")) el("songImage").src = s.img;
  if (exists("songTitle")) el("songTitle").innerText = s.title;
  if (exists("songArtist")) el("songArtist").innerText = s.artist;
  if (exists("audioPlayer")) el("audioPlayer").src = s.file;

  // Save button
  if (exists("saveBtn")) {
    el("saveBtn").onclick = () => {
      let library = JSON.parse(localStorage.getItem("library")) || [];
      if (!library.includes(id)) {
        library.push(id);
        localStorage.setItem("library", JSON.stringify(library));
        alert("Saved to Library");
        renderLibraryList(); // refresh if on library page
      } else {
        alert("Already in Library");
      }
    };
  }
}

/* -------------------------
   LIBRARY (library.html)
------------------------- */
function renderLibraryList() {
  const listEl = el("libraryList");
  if (!listEl) return;

  listEl.innerHTML = "";
  let library = JSON.parse(localStorage.getItem("library")) || [];

  if (library.length === 0) {
    listEl.innerHTML = `<p class="empty">Your library is empty</p>`;
    return;
  }

  library.forEach(id => {
    const s = songs[id];
    if (!s) return;

    const div = document.createElement("div");
    div.className = "song-card";

    div.innerHTML = `
      <img src="${s.img}" alt="${s.title}">
      <div class="song-info" onclick="openSong(${id})">
        <b>${s.title}</b>
        <small>${s.artist}</small>
      </div>
      <button class="delete-btn">Delete</button>
    `;

    div.querySelector(".delete-btn").onclick = (e) => {
      e.stopPropagation();
      library = library.filter(songId => songId != id);
      localStorage.setItem("library", JSON.stringify(library));
      renderLibraryList();
    };

    listEl.appendChild(div);
  });
}


/* -------------------------
   SEARCH (search.html)
------------------------- */
function setupSearch() {
  const input = el("searchInput");
  const results = el("results");
  if (!input || !results) return;

  const doSearch = () => {
    const q = input.value.trim().toLowerCase();
    results.innerHTML = "";
    if (q === "") {
      results.innerHTML = `<p class="empty">Type to search songs or artists</p>`;
      return;
    }
    let found = 0;
    Object.keys(songs).forEach(id => {
      const s = songs[id];
      if (s.title.toLowerCase().includes(q) || s.artist.toLowerCase().includes(q)) {
        found++;
        results.innerHTML += `
          <div class="song-card" onclick="openSong(${id})">
            <img src="${s.img}" alt="${s.title}">
            <div class="song-info">
              <b>${s.title}</b>
              <small>${s.artist}</small>
            </div>
          </div>
        `;
      }
    });
    if (found === 0) results.innerHTML = `<p class="empty">No results found</p>`;
  };

  input.addEventListener("input", doSearch);
  results.innerHTML = `<p class="empty">Type to search songs or artists</p>`;
}

/* -------------------------
   CONTACT (contact.html)
   - client-only success message (no backend)
------------------------- */
function setupContact() {
  const sendBtn = el("sendBtn");
  const nameBox = el("nameBox");
  const emailBox = el("emailBox");
  const messageBox = el("messageBox");
  const successMsg = el("successMsg");

  if (!sendBtn) return;

  sendBtn.onclick = () => {
    if (!nameBox.value.trim() || !emailBox.value.trim() || !messageBox.value.trim()) {
      alert("Please fill all fields.");
      return;
    }

    // Show success (client-side demonstration)
    successMsg.style.display = "block";

    // Clear fields
    nameBox.value = "";
    emailBox.value = "";
    messageBox.value = "";

    // Hide after a bit
    setTimeout(() => {
      successMsg.style.display = "none";
    }, 3000);
  };
}

/* -------------------------
   INIT (run on DOM ready)
------------------------- */
document.addEventListener("DOMContentLoaded", () => {
  renderHomeList();   // safe — will no-op if not on index.html
  loadSongPage();     // if on song.html, loads song
  renderLibraryList();// if on library.html renders library
  setupSearch();      // if on search.html sets up search
  setupContact();     // if on contact.html sets up contact
});